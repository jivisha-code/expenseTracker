package com.project.lms.ExpenseTrackerLms.repository;

import com.project.lms.ExpenseTrackerLms.entity.ContactForm;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactFormRepository extends JpaRepository<ContactForm, Long> {}

