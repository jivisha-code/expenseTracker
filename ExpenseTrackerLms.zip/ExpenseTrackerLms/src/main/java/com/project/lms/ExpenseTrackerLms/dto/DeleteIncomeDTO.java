//package com.project.lms.ExpenseTrackerLms.dto;
//
//import lombok.Data;
//
//import java.time.LocalDate;
//
//@Data
//public class DeleteIncomeDTO {
//    private Long incomeId;
//    private Long userId;
//}
